package com.crm.qa.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class LoginPage extends TestBase {
	
	//Page Factory - OR:Define the Object Repository for this Page
		@FindBy(name="username")
		WebElement username;
		
		@FindBy(name="password")
		WebElement password;
		
		@FindBy(xpath="//input[@type='submit']")
		WebElement loginBtn;
		
		//<button type="button" class="btn">Sign Up</button>
		@FindBy(xpath="//button[contains(text(),'Sign Up')]")
		WebElement signUpBtn;
		
		//<img class="img-responsive" src="https://d19rqa8v8yb76c.cloudfront.net/img/freecrm.jpg" alt="">
		@FindBy(xpath="//img[contains(@class,'img-responsive')]")
		WebElement crmLogo;
		
		
		//Initializing the Page Objects:using Page factory
		//this keyword contains all page webelements as declared above
		public LoginPage(){
			
			PageFactory.initElements(driver, this);
		}

		//Actions:
		public String validateLoginPageTitle(){
			return driver.getTitle();
		}
		
		//isdisplayed return type is boolean
		public boolean validateCRMImage(){
			return crmLogo.isDisplayed();
		}
		
		public HomePage login(String un, String pwd){
			username.sendKeys(un);
			password.sendKeys(pwd);
			//loginBtn.click();
			
			JavascriptExecutor js = (JavascriptExecutor)driver;
	    	js.executeScript("arguments[0].click();", loginBtn);
			
			return new HomePage();
		}
		

}
